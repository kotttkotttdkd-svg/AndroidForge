package com.kotttkottt.tracker;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.*;
import android.graphics.Typeface;
import android.view.Gravity;

public class MainActivity extends Activity {
    private TextView countView, statusView, historyView;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("tracker", MODE_PRIVATE);
        createChannel();
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 36, 28, 24);
        layout.setBackgroundColor(0xFFF5F6FA);

        TextView title = new TextView(this);
        title.setText("KOTTTKOTTT");
        title.setTextSize(28); title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFF172033);
        layout.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("YouTube subscriber tracker");
        subtitle.setTextSize(15); subtitle.setTextColor(0xFF667085);
        layout.addView(subtitle);

        countView = new TextView(this);
        countView.setTextSize(42); countView.setTypeface(null, Typeface.BOLD);
        countView.setTextColor(0xFF176B55);
        countView.setPadding(0, 32, 0, 4);
        layout.addView(countView);

        statusView = new TextView(this);
        statusView.setTextSize(14); statusView.setTextColor(0xFF475467);
        statusView.setPadding(0, 0, 0, 20);
        layout.addView(statusView);

        Button access = new Button(this);
        access.setText("1. Увімкнути доступ до зчитування");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(access);

        Button studio = new Button(this);
        studio.setText("2. Відкрити YouTube Studio");
        studio.setOnClickListener(v -> {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.google.android.apps.youtube.creator");
            if (i != null) startActivity(i);
            else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://studio.youtube.com")));
        });
        layout.addView(studio);

        Button refresh = new Button(this);
        refresh.setText("Оновити показники");
        refresh.setOnClickListener(v -> updateScreen());
        layout.addView(refresh);

        TextView note = new TextView(this);
        note.setText("Важливо: Android дозволяє зчитувати число лише тоді, коли YouTube Studio відкрита на екрані й показує лічильник. Це не фоновий доступ до закритої Studio. Імена підписників не збираються.");
        note.setTextSize(13); note.setTextColor(0xFF8A4B08);
        note.setPadding(0, 20, 0, 20);
        layout.addView(note);

        TextView histTitle = new TextView(this);
        histTitle.setText("ІСТОРІЯ ЗМІН");
        histTitle.setTypeface(null, Typeface.BOLD);
        histTitle.setTextColor(0xFF344054);
        layout.addView(histTitle);

        historyView = new TextView(this);
        historyView.setTextSize(14); historyView.setTextColor(0xFF344054);
        historyView.setPadding(0, 8, 0, 0);
        layout.addView(historyView);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(layout);
        setContentView(scroll);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 20);
        updateScreen();
    }

    @Override protected void onResume() { super.onResume(); updateScreen(); }

    private void updateScreen() {
        int count = prefs.getInt("last_count", -1);
        countView.setText(count >= 0 ? String.format("%,d", count) : "—");
        boolean enabled = false;
        try {
            String setting = android.provider.Settings.Secure.getString(getContentResolver(), "enabled_accessibility_services");
            enabled = setting != null && setting.contains(getPackageName());
        } catch (Exception ignored) {}
        statusView.setText(enabled ? "Сервіс доступності: увімкнений" : "Сервіс доступності: ще не увімкнений");
        historyView.setText(prefs.getString("history", "Поки немає зафіксованих змін."));
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel("subs", "Зміни підписників", NotificationManager.IMPORTANCE_DEFAULT);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }
}
