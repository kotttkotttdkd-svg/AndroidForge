package com.kotttkottt.tracker;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import java.util.regex.*;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;

public class SubscriberAccessibilityService extends AccessibilityService {
    private static final Pattern NUMBER = Pattern.compile("(?<![\\d])([0-9][0-9 ,.\\u00A0]{0,12}[0-9]|[0-9]{1,3})(?![\\d])");
    private static final String[] WORDS = {"subscriber", "subscribers", "підписник", "підписники", "підписників", "suscriptores", "abonnés"};
    private long lastScan = 0;

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null ||
            !event.getPackageName().toString().equals("com.google.android.apps.youtube.creator")) return;
        long now = System.currentTimeMillis();
        if (now - lastScan < 500) return;
        lastScan = now;
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        List<String> texts = new ArrayList<>();
        collect(root, texts);
        for (int i = 0; i < texts.size(); i++) {
            String s = texts.get(i);
            String lower = s.toLowerCase(Locale.ROOT);
            boolean label = false;
            for (String w : WORDS) if (lower.contains(w)) label = true;
            if (!label) continue;
            Matcher m = NUMBER.matcher(s);
            while (m.find()) {
                String raw = m.group(1).replaceAll("[^0-9]", "");
                try {
                    int value = Integer.parseInt(raw);
                    if (value >= 1 && value <= 1000000000) { saveCount(value); return; }
                } catch (Exception ignored) {}
            }
            if (i + 1 < texts.size()) {
                Matcher next = NUMBER.matcher(texts.get(i + 1));
                if (next.find()) {
                    String raw = next.group(1).replaceAll("[^0-9]", "");
                    try {
                        int value = Integer.parseInt(raw);
                        if (value >= 1 && value <= 1000000000) { saveCount(value); return; }
                    } catch (Exception ignored) {}
                }
            }
        }
    }

    private void collect(AccessibilityNodeInfo node, List<String> out) {
        if (node == null) return;
        CharSequence t = node.getText();
        if (t != null && t.length() > 0) out.add(t.toString());
        CharSequence d = node.getContentDescription();
        if (d != null && d.length() > 0) out.add(d.toString());
        for (int i = 0; i < node.getChildCount(); i++) collect(node.getChild(i), out);
    }

    private void saveCount(int value) {
        android.content.SharedPreferences p = getSharedPreferences("tracker", MODE_PRIVATE);
        int old = p.getInt("last_count", -1);
        if (old == value) return;
        String stamp = new java.text.SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault()).format(new java.util.Date());
        String line = stamp + "  •  " + NumberFormat.getIntegerInstance(Locale.getDefault()).format(value);
        String history = p.getString("history", "");
        if (old >= 0) {
            int diff = value - old;
            String change = diff > 0 ? " (+" + diff + ")" : " (" + diff + ")";
            line += change;
            if (diff > 0) notifyChange(diff, value);
        }
        history = line + (history.isEmpty() ? "" : "\n" + history);
        p.edit().putInt("last_count", value).putString("history", history).apply();
    }

    private void notifyChange(int diff, int value) {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            new NotificationChannel("subs", "Зміни підписників", NotificationManager.IMPORTANCE_DEFAULT));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, "subs") : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
         .setContentTitle("KOTTTKOTTT: новий підписник")
         .setContentText("+" + diff + " • Разом: " + NumberFormat.getIntegerInstance().format(value))
         .setAutoCancel(true);
        try { nm.notify(1001, b.build()); } catch (SecurityException ignored) {}
    }

    @Override public void onInterrupt() {}
}
